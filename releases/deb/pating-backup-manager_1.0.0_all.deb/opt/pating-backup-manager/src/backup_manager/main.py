import os
import sys

if getattr(sys, 'frozen', False):
    base_path = sys._MEIPASS
    typelib_path = os.path.join(base_path, "gi_typelibs")
    os.environ["GI_TYPELIB_PATH"] = typelib_path

import gi

gi.require_version("Gtk", "4.0")
from gi.repository import Gtk, Gio

from backup_manager.window import BackupWindow


class BackupApp(Gtk.Application):
    def __init__(self):
        super().__init__(
            application_id="com.example.LinuxBackup",
            flags=Gio.ApplicationFlags.DEFAULT_FLAGS,
        )
        quit_action = Gio.SimpleAction.new("quit", None)
        quit_action.connect("activate", self.on_quit_action)
        self.add_action(quit_action)
        self.window = None

    def on_quit_action(self, *_args):
        if self.window is None:
            self.quit()
            return
        self.window.confirm_quit()

    def do_activate(self):
        if self.window is None:
            self.window = BackupWindow(self)
        self.window.present()